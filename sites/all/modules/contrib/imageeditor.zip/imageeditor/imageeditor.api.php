<?php
/**
 * @file
 * Image Editor API functions.
 */

function imageeditor_initialize($editors, $uploaders) {

}

function imageeditor_info($type = 'editor') {

}
