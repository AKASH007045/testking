<div class="imageeditor-webcams">
  <div class="camera-wrapper">
    <div class="camera"></div>
  </div>
  <div class="controls-wrapper">
    <div class="controls">
      <div class="controls-shot">Take an image</div>
    </div>
  </div>
  <div class="gallery-wrapper">
    <div class="gallery"></div>
  </div>
</div>